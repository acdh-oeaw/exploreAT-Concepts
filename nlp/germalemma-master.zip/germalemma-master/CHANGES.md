# Changes

## 0.1.1 - 2019-01-30

* minor improvements in `find_lemma`


## 0.1.0 - 2019-01-30

* initial release on PyPI
  
